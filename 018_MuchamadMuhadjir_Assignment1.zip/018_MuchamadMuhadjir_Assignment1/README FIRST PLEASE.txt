Link Github Untuk Assignment 1: https://github.com/Muhadjir/OCBC-H8/tree/main/018_MuchamadMuhadjir_Assignment1

Assalamu'alaikum Wr. Wb.
Saya Muchamad Muhadjir
Kode Peserta FSDO001ONL018
Alamat Jl. Pucangan 4/32-A Surabaya

Pada Assignment 1 yang saya kerjakan berikut adalah panduannya:
1. Hanya menggunakan mono sebagai run code nya.
2. Terdapat tampilan yang terdiri dari 8 menu, 6 Soal dan 2 Tampilan.
3. Tiap Soal akan memasukkan input sebagai data dinamis yang akan di proses.
(Pastikan Sesuai dengan yang disarankan oleh program!)
4. Pada saat menu sudah dipilih dan diproses, akan ada pertanyaan kembali ke menu atau tidak.

Note: 	Pastikan untuk melihat program dengan keadaan sehat dan sudah makan dan minum.
	Karena Kesehatan merupakan rezeki yang banyak orang tidak sadari.

Sekian, Terima Kasih atas kunjungannya. Sampai Jumpa untuk Assignment 2 yaaa ^_^

Wassalamu'alaikum Wr. Wb.